# CLAUDE.md — Instructions de reprise pour Claude Code

Ce dépôt contient la version initiale fonctionnelle de **LumiMath**, une application éducative mobile-first (PWA) d'apprentissage des mathématiques pour les enfants de **6 à 12 ans** (**CP à 6e**), inspirée de l'expérience **Brilliant**.

Tu reprends un **prototype existant, compilé et vérifié**, et **non** un projet à recommencer de zéro.

---

## Ordre de lecture obligatoire avant toute modification

Avant d'éditer le moindre fichier :

1. Lire intégralement `docs/handoff/HANDOFF.md`.
2. Lire `docs/handoff/FEATURE_STATUS.md`.
3. Lire `docs/handoff/NEXT_STEPS.md`.
4. Lire `docs/handoff/DESIGN_SYSTEM.md`.
5. Lire `docs/handoff/SVG_ANIMATIONS.md`.
6. Examiner l'architecture réelle du projet (`docs/handoff/ARCHITECTURE.md` et les fichiers concernés dans `src/`) avant de modifier le code.
7. Ne jamais remplacer le design existant sans justification.
8. Ne jamais supprimer les animations SVG fonctionnelles.
9. Préserver les fonctionnalités déjà validées.
10. Mettre à jour les documents de passation après chaque évolution importante.

---

## Règles architecturales

- **Séparation stricte données / logique / UI** :
  - Les types vivent dans `src/types/math.ts`.
  - La logique métier pure (progression, XP, étoiles, défis quotidiens, rollover journalier) vit dans `src/utils/gameLogic.ts` et doit rester testable sans DOM via `src/utils/gameLogic.test.ts`.
  - Les contenus pédagogiques adaptatifs par niveau (`CP`–`6e`) vivent dans `src/data/curriculum.ts` et les badges dans `src/data/rewards.ts`.
  - Les écrans et composants visuels vivent dans `src/components/`.
- **Full-stack Express + Vite** :
  - `server.ts` sert le backend (`/api/health`, `/api/config`, `/api/tutor`) et monte Vite en middleware en développement (`npm run dev`). En production (`npm start`), il sert `dist/`.
  - La clé `GEMINI_API_KEY` reste **strictement côté serveur**. Ne jamais appeler `@google/genai` depuis le navigateur.
- **Persistance locale** :
  - Toute l'état utilisateur (`UserState`) est persisté dans `localStorage` sous la clé `lumimath_brilliant_v2` (constante `STORAGE_KEY`). Conserver la rétrocompatibilité lors de l'ajout de nouveaux champs (`loadUserState` fusionne avec `createInitialUserState()`).

---

## Règles de design à respecter

- **Direction artistique Brilliant (pas de clone Duolingo)** :
  - Fond principal blanc pur (`#FFFFFF`), cartes neutres `#F7F8FA`, bordures fines `#E5E7EB`.
  - CTA principaux sombres en pilule (`bg-[#111827] text-white rounded-full`).
  - Progression, validation et tiroirs de réussite en vert émeraude (`#22C55E` / `#DCFCE7` / `#15803D`).
  - Compteur d'XP éclair jaune (`#FACC15` / `#EAB308`). Aucun système de cœurs/vies punitif.
- **Typographie** : `Fredoka` pour les titres (`.font-display`), `Nunito` pour le corps de texte, `tabular-nums` sur tous les compteurs et équations.
- **Ergonomie mobile** :
  - Hauteur `100dvh`, zones tactiles `>= 44px`, zéro débordement horizontal à `390px` de large.
  - Tout le texte visible de l'application est en **français**, adapté à un enfant de 6 à 12 ans.

---

## Consignes concernant les SVG et les animations

- **Conserver l'asset original** : `public/assets/aistudio/Turkey_Power_Walk_3833b87d.svg` est la source de vérité vectorielle.
- **Ne jamais remplacer la mascotte par une image raster générée ou générique**.
- La géométrie extraite dans `src/components/mascot/turkeySvgData.ts` est rendue et animée dans `src/components/mascot/TurkeyMascot.tsx` via `src/components/mascot/MascotController.tsx`.
- **Précaution SVG Motion** : dans `TurkeyMascot.tsx`, animer `scaleX`/`scaleY`/`rotate`/`x`/`y` avec `style={{ transformOrigin: ... }}` plutôt que des attributs géométriques comme `rx` sur `<motion.ellipse>` (qui déclenchent des erreurs navigateur `Expected length, "undefined"`).
- Respecter `prefers-reduced-motion` via `<MotionConfig reducedMotion="user">` dans `src/App.tsx` et les règles CSS dans `src/index.css`.

---

## Conventions de code & commandes

- TypeScript strict (`tsc --noEmit` sans erreur), React 19 fonctionnel avec hooks, Tailwind CSS v4 (`@import "tailwindcss";` dans `src/index.css`, sans fichiers CSS par composant).
- Composants natifs accessibles (`<button type="button">`, `aria-label`, `aria-current`) plutôt que des `<div>` cliquables.

```bash
npm run dev                                  # Développement (port 3000)
npm run lint                                 # Vérification TypeScript (tsc --noEmit)
npx tsx --test src/utils/gameLogic.test.ts   # Tests unitaires
npm run build                                # Build production + PWA
npm start                                    # Serveur production
```

---

## Précautions avant toute modification

1. Ne pas modifier `metadata.json` (`majorCapabilities`) ni casser le proxy `/api/tutor`.
2. Après modification de `src/utils/gameLogic.ts` ou `src/data/curriculum.ts`, exécuter `npx tsx --test src/utils/gameLogic.test.ts`.
3. Avant de valider une évolution UI, exécuter `npm run lint`, `npm run build` et vérifier le rendu en mobile `390×844` (zéro overflow, zéro erreur console).
4. Si la structure du `UserState` ou une nouvelle fonctionnalité évolue, mettre à jour `docs/handoff/FEATURE_STATUS.md`, `docs/handoff/ARCHITECTURE.md` et `docs/handoff/NEXT_STEPS.md`.
