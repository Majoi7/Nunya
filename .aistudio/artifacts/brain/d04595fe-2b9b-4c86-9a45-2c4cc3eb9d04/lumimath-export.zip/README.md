# LumiMath

Application web mobile-first (PWA) d'apprentissage actif des mathématiques pour les enfants de **6 à 12 ans** (**CP à 6e**), inspirée de la pédagogie par découverte et manipulation de **Brilliant**.

L'enfant découvre les notions en observant des schémas visuels, en manipulant directement des objets, grilles, paniers ou figures géométriques SVG, puis en répondant à des défis accompagnés par **Coach Dindon** (mascotte SVG articulée) et un tuteur IA optionnel côté serveur.

---

## Fonctionnalités principales

- **5 chapitres, 10 notions adaptatives (CP → 6e)** :
  1. *Addition & Assemblage* (Réunir deux groupes, Compléter un total)
  2. *Soustraction & Écart* (Retirer pour observer, Trouver la différence)
  3. *Multiplication en Grilles* (Lignes et colonnes, Facteurs et produits)
  4. *Partage & Division* (Partage équitable, Lien × et ÷)
  5. *Découverte de la Géométrie* (Polygones & Sommets, Angles droits & Propriétés)
- **Pédagogie active en 7 étapes** : Découverte → Observation → Manipulation tactile → Question → Feedback immédiat → Explication visuelle (`Pourquoi ?`) → Application & Bilan.
- **Mascotte SVG articulée** (`MascotController` / `TurkeyMascot`) issue du SVG original `Turkey_Power_Walk_3833b87d.svg` avec 8 états comportementaux, clignement des yeux et suivi du regard.
- **Sauvegarde locale automatique** (`localStorage`, clé `lumimath_brilliant_v2`) : XP, série quotidienne, étoiles, badges et classe active.
- **PWA installable & partage smartphone** : manifeste web, service worker Workbox et modale QR code dynamique (`qrcode.react`).
- **Tuteur IA Gemini optionnel** via `/api/tutor` (`server.ts`), avec repli déterministe hors-ligne instantané.

---

## Prérequis & lancement local

- **Node.js** `>= 20` (recommandé : Node 22 LTS)
- **npm** (ou **Bun**)

```bash
# 1. Installer les dépendances
npm install

# 2. Copier les variables d'environnement (optionnel pour le tuteur Gemini)
cp .env.example .env

# 3. Lancer le serveur de développement (Express + Vite middleware sur le port 3000)
npm run dev
```

Ouvrir ensuite [http://localhost:3000](http://localhost:3000).

### Autres commandes utiles

| Commande | Description |
|---|---|
| `npm run lint` | Vérifie le typage TypeScript (`tsc --noEmit`) |
| `npm run build` | Compile le bundle frontend + PWA dans `dist/` |
| `npm start` | Lance le serveur Express en mode production (`NODE_ENV=production`) |
| `npx tsx --test src/utils/gameLogic.test.ts` | Exécute les tests unitaires métier (`node:test`) |

---

## Variables d'environnement (`.env`)

Voir `.env.example` :

- `GEMINI_API_KEY` *(optionnel)* : active l'enrichissement des explications pédagogiques sur `POST /api/tutor`. Sans clé valide, l'application bascule automatiquement sur `buildOfflineTutorResponse`.
- `APP_URL` *(optionnel)* : URL publique utilisée pour générer le QR code scannable lorsque l'application est ouverte en local.

---

## Documentation de passation (Claude Code)

- Instructions de travail pour Claude Code : [`CLAUDE.md`](./CLAUDE.md)
- Documentation détaillée : [`docs/handoff/`](./docs/handoff/)
  - [`HANDOFF.md`](./docs/handoff/HANDOFF.md) — Guide principal de reprise
  - [`ARCHITECTURE.md`](./docs/handoff/ARCHITECTURE.md) — Architecture réelle et flux de données
  - [`DESIGN_SYSTEM.md`](./docs/handoff/DESIGN_SYSTEM.md) — Système graphique inspiré de Brilliant
  - [`SVG_ANIMATIONS.md`](./docs/handoff/SVG_ANIMATIONS.md) — Rig SVG de la mascotte et diagrammes interactifs
  - [`FEATURE_STATUS.md`](./docs/handoff/FEATURE_STATUS.md) — État honnête des fonctionnalités
  - [`KNOWN_ISSUES.md`](./docs/handoff/KNOWN_ISSUES.md) — Limites et problèmes connus
  - [`NEXT_STEPS.md`](./docs/handoff/NEXT_STEPS.md) — Feuille de route priorisée P0–P3
